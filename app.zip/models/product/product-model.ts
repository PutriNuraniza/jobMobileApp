export class Product {
    id: number;
    name: string;
    price: number;
    categori_id: number;
    active: boolean;
    image: string;
}